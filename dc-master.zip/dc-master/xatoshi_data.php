<?php
# config by : muh maulana
# channel : xatoshi lanzz
# telegram : @xatoshilanzz & @cxatoshi

$email = "fatursytx@gmail.com";
$password = "rattlexnake1404";
?>
